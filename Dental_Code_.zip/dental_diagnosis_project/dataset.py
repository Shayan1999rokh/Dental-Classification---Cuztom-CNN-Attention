from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

from config import CONFIG
from preprocessing import apply_preprocessing

class DentalXrayDataset(Dataset):
    def __init__(self, manifest, preprocess=True, image_size=None, return_metadata=False):
        self.frame = manifest.reset_index(drop=True).copy()
        self.preprocess = bool(preprocess)
        self.image_size = int(image_size or CONFIG.image_size)
        self.return_metadata = return_metadata

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, index):
        row = self.frame.iloc[index]
        path = Path(row["image_path"])
        image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if image is None:
            raise IOError(f"Cannot read image: {path}")
        array = apply_preprocessing(
            image, enabled=self.preprocess, image_size=self.image_size
        )
        tensor = torch.from_numpy(
            np.ascontiguousarray(array.transpose(2, 0, 1))
        ).float()
        label = torch.tensor(int(row["label_id"]), dtype=torch.long)
        if self.return_metadata:
            return tensor, label, str(row["original_image_id"])
        return tensor, label

def make_dataloader(dataset, batch_size, shuffle=False, num_workers=None):
    if num_workers is None:
        num_workers = CONFIG.num_workers
    return DataLoader(
        dataset, batch_size=int(batch_size), shuffle=bool(shuffle),
        num_workers=int(num_workers), pin_memory=torch.cuda.is_available(),
        drop_last=False
    )
