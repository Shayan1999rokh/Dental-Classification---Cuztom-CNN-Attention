from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier

from config import CONFIG

def build_hybrid_classifier(name, random_state=None):
    """Classical ML classifier for CNN-derived feature vectors."""
    random_state = CONFIG.random_seed if random_state is None else random_state
    name = name.lower()

    if name == "svm":
        estimator = SVC(
            C=CONFIG.svm_c, kernel=CONFIG.svm_kernel,
            gamma=CONFIG.svm_gamma, probability=True,
            random_state=random_state
        )
    elif name in {"rf", "random_forest"}:
        estimator = RandomForestClassifier(
            n_estimators=CONFIG.random_forest_estimators,
            criterion="gini",
            # Modern equivalent of the deprecated old sklearn "auto" for classifiers.
            max_features="sqrt",
            random_state=random_state,
            n_jobs=-1,
        )
    elif name in {"dt", "decision_tree"}:
        estimator = DecisionTreeClassifier(
            criterion="gini", max_depth=None, min_samples_split=2,
            random_state=random_state
        )
    else:
        raise ValueError("name must be svm, rf, or dt")
    # Scaling is fitted on the training fold only. It is unnecessary for trees
    # but retained for a uniform, leakage-safe pipeline matching the paper table.
    return Pipeline([("scaler", StandardScaler()), ("classifier", estimator)])
