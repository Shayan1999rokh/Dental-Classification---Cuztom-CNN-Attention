from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon, friedmanchisquare


def holm_adjust(p_values):
    p_values = np.asarray(p_values, dtype=float)
    order = np.argsort(p_values)
    adjusted = np.empty_like(p_values)
    running = 0.0
    m = len(p_values)
    for rank, idx in enumerate(order):
        value = min(1.0, (m - rank) * p_values[idx])
        running = max(running, value)
        adjusted[idx] = running
    return adjusted


def compare_models(results_csv, metric="accuracy", output_path=None):
    """
    Paired fold-wise Wilcoxon tests, optional Friedman omnibus test, and
    Holm correction. With five folds, treat p-values as exploratory.
    """
    frame = pd.read_csv(results_csv)
    needed = {"fold", "model", metric}
    if not needed.issubset(frame.columns):
        raise ValueError(f"Results CSV must include {sorted(needed)}")
    if {"attention", "preprocessing"}.issubset(frame.columns):
        frame["comparison_name"] = (
            frame["model"].astype(str)
            + "|att=" + frame["attention"].astype(str)
            + "|prep=" + frame["preprocessing"].astype(str)
        )
        column_name = "comparison_name"
    else:
        column_name = "model"
    wide = frame.pivot_table(index="fold", columns=column_name, values=metric)
    wide = wide.dropna(axis=0, how="any")
    names = list(wide.columns)
    rows = []

    if len(names) >= 3 and len(wide) >= 2:
        try:
            stat, p = friedmanchisquare(*[wide[name].values for name in names])
            rows.append({
                "test": "Friedman", "model_a": "all", "model_b": "all",
                "statistic": float(stat), "p_value": float(p),
                "p_value_holm": float("nan")
            })
        except ValueError:
            pass

    pair_rows = []
    for a, b in combinations(names, 2):
        try:
            stat, p = wilcoxon(wide[a].values, wide[b].values)
        except ValueError:
            stat, p = 0.0, 1.0
        pair_rows.append({
            "test": "Wilcoxon signed-rank", "model_a": a, "model_b": b,
            "statistic": float(stat), "p_value": float(p)
        })
    if pair_rows:
        adjusted = holm_adjust([r["p_value"] for r in pair_rows])
        for row, corrected in zip(pair_rows, adjusted):
            row["p_value_holm"] = float(corrected)
        rows.extend(pair_rows)

    result = pd.DataFrame(rows)
    if output_path:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        result.to_csv(output_path, index=False)
    return result


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True)
    parser.add_argument("--metric", default="accuracy")
    parser.add_argument("--output", default="outputs/statistical_comparisons.csv")
    args = parser.parse_args()
    print(compare_models(args.results, args.metric, args.output).to_string(index=False))
