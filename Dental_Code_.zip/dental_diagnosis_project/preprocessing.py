import argparse
from pathlib import Path

import cv2
import numpy as np

from config import CONFIG

def apply_preprocessing(
    image, enabled=True, image_size=None, alpha=None, beta=None,
    clahe_clip_limit=None, clahe_grid_size=None
):
    """
    With preprocessing: brightness I'=1.5*I+15, CLAHE(2.0,(3,3)),
    resize to 128x128 using nearest-neighbor, then min-max normalize.
    Without preprocessing: skip brightness and CLAHE, but retain resizing
    and normalization required by the neural-network input.
    """
    image_size = int(image_size or CONFIG.image_size)
    alpha = CONFIG.brightness_alpha if alpha is None else alpha
    beta = CONFIG.brightness_beta if beta is None else beta
    clip = CONFIG.clahe_clip_limit if clahe_clip_limit is None else clahe_clip_limit
    grid = CONFIG.clahe_tile_grid_size if clahe_grid_size is None else clahe_grid_size

    if image is None:
        raise ValueError("Input image is None.")
    if image.ndim == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image = image.astype(np.uint8, copy=False)

    if enabled:
        # The article's workflow applies enhancement and then the ROI mask.
        # Since the builder has already saved masked images, preserve their
        # zero-valued background during enhancement.
        roi_mask = image > 0
        image = cv2.convertScaleAbs(image, alpha=float(alpha), beta=int(beta))
        image = cv2.createCLAHE(
            clipLimit=float(clip), tileGridSize=tuple(grid)
        ).apply(image)
        image[~roi_mask] = 0

    image = cv2.resize(
        image, (image_size, image_size), interpolation=cv2.INTER_NEAREST
    ).astype(np.float32)
    low, high = float(image.min()), float(image.max())
    image = (image - low) / (high - low) if high > low else np.zeros_like(image)
    return np.repeat(image[:, :, None], 3, axis=2).astype(np.float32)

def preprocess_file(input_path, output_path, enabled=True):
    image = cv2.imread(str(input_path), cv2.IMREAD_GRAYSCALE)
    array = apply_preprocessing(image, enabled=enabled)
    output = np.clip(array[:, :, 0] * 255, 0, 255).astype(np.uint8)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output_path), output)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--without-enhancement", action="store_true")
    args = parser.parse_args()
    preprocess_file(args.image, args.output, not args.without_enhancement)

if __name__ == "__main__":
    main()
