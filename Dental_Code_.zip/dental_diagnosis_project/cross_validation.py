import numpy as np
from sklearn.model_selection import StratifiedGroupKFold, GroupKFold

from config import CONFIG

def make_grouped_folds(manifest, n_splits=None, random_state=None, stratified=True):
    """
    Group by original_image_id. All class-specific crops and augmented
    derivatives of one original panoramic X-ray remain in the same fold.
    This is a leakage-control safeguard; the paper does not fully specify
    whether its original folds were grouped this way.
    """
    n_splits = int(n_splits or CONFIG.n_splits)
    random_state = CONFIG.random_seed if random_state is None else random_state
    frame = manifest.reset_index(drop=True)
    y = frame["label_id"].astype(int).to_numpy()
    groups = frame["original_image_id"].astype(str).to_numpy()

    if len(np.unique(groups)) < n_splits:
        raise ValueError(f"Need at least {n_splits} unique source images for grouped CV.")

    if stratified:
        splitter = StratifiedGroupKFold(
            n_splits=n_splits, shuffle=True, random_state=random_state
        )
        iterator = splitter.split(np.zeros(len(frame)), y, groups)
    else:
        splitter = GroupKFold(n_splits=n_splits)
        iterator = splitter.split(np.zeros(len(frame)), y, groups)

    folds = []
    for fold_id, (train_idx, val_idx) in enumerate(iterator, start=1):
        train_groups = set(groups[train_idx])
        val_groups = set(groups[val_idx])
        if train_groups.intersection(val_groups):
            raise RuntimeError(f"Source-image leakage detected in fold {fold_id}.")
        folds.append((
            frame.iloc[train_idx].reset_index(drop=True),
            frame.iloc[val_idx].reset_index(drop=True),
        ))
    return folds
