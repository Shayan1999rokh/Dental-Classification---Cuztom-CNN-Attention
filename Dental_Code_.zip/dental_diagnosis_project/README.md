# Dental X-ray Diagnosis — Reproduction Code

Implementation scaffold for **Multi-label Diagnosis of Dental Conditions from
Panoramic X-rays Using Attention-Enhanced Deep Learning**, *Oral and
Maxillofacial Surgery* (2025), 29:166.
DOI: https://doi.org/10.1007/s10006-025-01463-y

## Included modules

1. `config.py` — shared paths and hyperparameters.
2. `utils.py` — seeds, manifest validation, logging, checkpoints.
3. `dataset_builder.py` — YOLO/COCO annotation parsing and class-specific box masking.
4. `preprocessing.py` — brightness, CLAHE, resizing, normalization.
5. `augmentation.py` — rotation/flips and class balancing.
6. `dataset.py` — PyTorch Dataset/DataLoader.
7. `cross_validation.py` — five-fold group-aware CV.
8. `attention.py` — spatial attention.
9. `custom_cnn.py` — custom CNN with optional attention.
10. `pretrained_models.py` — VGG16, ResNet50 and Xception with attention.
11. `hybrid_classifiers.py` — SVM, Random Forest and Decision Tree.
12. `train_deep_models.py` — deep-model training.
13. `feature_extraction.py` — CNN feature extraction for hybrid learning.
14. `train_hybrid.py` — CNN + classical ML pipeline.
15. `evaluation.py` — metrics and confusion matrix.
16. `statistical_analysis.py` — paired fold comparisons and Holm correction.
17. `visualization.py` — plots.
18. `run_experiments.py` — main experiment runner.
19. `inference.py` — prediction on one image.

## Install

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

Install the PyTorch build suitable for your CUDA version from https://pytorch.org/.

## Input data

The original paper reports 1,512 panoramic X-rays with bounding-box annotations.
This implementation supports YOLO text labels and COCO JSON annotations.

YOLO example:

```text
dataset/
  data.yaml
  images/train/*.jpg
  labels/train/*.txt
```

Run from the project directory:

```bash
python run_experiments.py --experiment data --build-data \
  --image-dir /path/to/dataset/images/train \
  --annotation-dir /path/to/dataset/labels/train \
  --data-yaml /path/to/dataset/data.yaml \
  --annotation-format yolo
```

COCO example:

```bash
python run_experiments.py --experiment data --build-data \
  --image-dir /path/to/images \
  --annotation-format coco \
  --coco-json /path/to/annotations.json
```

The builder creates a class-specific rectangular mask for each class present
in an original X-ray. This is the paper's bounding-box masking procedure; it
is not a learned segmentation network. The balancing script targets 1,191
samples per class, as reported in the paper.

## Run experiments

```bash
python run_experiments.py --experiment custom \
  --manifest data/balanced/manifest.csv --preprocessing both

python run_experiments.py --experiment pretrained \
  --manifest data/balanced/manifest.csv --preprocessing both

python run_experiments.py --experiment hybrid \
  --manifest data/balanced/manifest.csv --preprocessing both

python run_experiments.py --experiment all \
  --manifest data/balanced/manifest.csv --preprocessing both
```

Use `--device cpu`, `--device cuda`, or `--device auto`.
The `all` option is computationally expensive.

## Methodological notes and paper ambiguities

- The article's title says "multi-label", but the described model uses four
  Softmax outputs and Argmax. This code implements four-class single-label
  classification.
- Table 3 gives Custom CNN batch size 16 and 30 epochs, while the prose gives
  batch size 32 and up to 50 epochs. Defaults follow Table 3; edit `config.py`
  to test the prose values.
- The article's attention equations have shape ambiguities. This code implements
  a spatial attention projection over H*W positions, Softmax-normalized and
  multiplied into the feature map.
- The article's pretrained-model description is not fully consistent about
  Global Average Pooling versus spatial Attention order. Here, attention is
  applied to the final spatial feature map before global average pooling.
- The article says DT has "Estimators=100"; that is not a Decision Tree
  hyperparameter. This code does not invent that parameter. Random Forest
  uses 100 trees.
- The article does not clearly document fold grouping. This implementation
  uses `StratifiedGroupKFold` grouped by `original_image_id`, so class-specific
  crops and augmentations from the same original X-ray cannot cross folds.
  This is a methodological safeguard, not a claim that the paper used it.
- The paper's hybrid description uses flattened CNN feature maps. At 128x128
  input this creates 65,536 features/sample; Random Forest can therefore be
  memory intensive. A pooled/PCA variant would be a separate experiment and
  must not be reported as exact reproduction.
- The article has no normal/healthy class. Predictions are restricted to the
  four annotated positive-condition classes and are not a clinical diagnosis.
- The code is a reproducible implementation scaffold. The exact Roboflow
  export's directory layout, class-name mapping and annotation format should
  be checked before running it on the actual data.
