import torch
from torch import nn
from torchvision.models import vgg16, resnet50, VGG16_Weights, ResNet50_Weights

from attention import SpatialAttentionBlock

class PretrainedDentalModel(nn.Module):
    """
    VGG16 / ResNet50 / Xception ImageNet backbones with attention and a
    four-class head. Xception uses timm. Last backbone block is trainable,
    following the paper's stated fine-tuning strategy.
    """
    def __init__(self, model_name="vgg16", num_classes=4, pretrained=True):
        super().__init__()
        self.model_name = model_name.lower()

        if self.model_name == "vgg16":
            base = vgg16(weights=VGG16_Weights.DEFAULT if pretrained else None)
            self.backbone = base.features
            self.feature_channels = 512
            for p in self.backbone.parameters():
                p.requires_grad = False
            for layer in list(self.backbone.children())[24:]:
                for p in layer.parameters():
                    p.requires_grad = True

        elif self.model_name == "resnet50":
            self.backbone = resnet50(
                weights=ResNet50_Weights.DEFAULT if pretrained else None
            )
            self.feature_channels = 2048
            for p in self.backbone.parameters():
                p.requires_grad = False
            for p in self.backbone.layer4.parameters():
                p.requires_grad = True

        elif self.model_name == "xception":
            try:
                import timm
            except ImportError as exc:
                raise ImportError("Install timm to use Xception: pip install timm") from exc
            self.backbone = timm.create_model(
                "xception", pretrained=pretrained, features_only=True, out_indices=(-1,)
            )
            self.feature_channels = int(self.backbone.feature_info.channels()[-1])
            for p in self.backbone.parameters():
                p.requires_grad = False
            base = getattr(self.backbone, "model", self.backbone)
            if hasattr(base, "blocks") and len(base.blocks):
                for p in base.blocks[-1].parameters():
                    p.requires_grad = True
            else:
                children = list(base.children())
                if children:
                    for p in children[-1].parameters():
                        p.requires_grad = True
        else:
            raise ValueError("model_name must be vgg16, resnet50, or xception.")

        self.attention = SpatialAttentionBlock(self.feature_channels)
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.classifier = nn.Sequential(
            nn.Linear(self.feature_channels, 256), nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, 128), nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(128, num_classes)
        )

    def _feature_map(self, x):
        if self.model_name == "vgg16":
            return self.backbone(x)
        if self.model_name == "resnet50":
            b = self.backbone
            x = b.maxpool(b.relu(b.bn1(b.conv1(x))))
            x = b.layer1(x)
            x = b.layer2(x)
            x = b.layer3(x)
            return b.layer4(x)
        output = self.backbone(x)
        return output[-1] if isinstance(output, (tuple, list)) else output

    def extract_features(self, x):
        feature_map = self.attention(self._feature_map(x))
        return torch.flatten(self.pool(feature_map), start_dim=1)

    def forward(self, x):
        return self.classifier(self.extract_features(x))

def build_pretrained_model(model_name, num_classes=4, pretrained=True):
    return PretrainedDentalModel(model_name, num_classes, pretrained)
