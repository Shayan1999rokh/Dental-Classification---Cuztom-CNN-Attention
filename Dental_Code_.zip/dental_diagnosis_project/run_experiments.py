import argparse
from pathlib import Path

import pandas as pd

from config import CONFIG
from dataset_builder import build_class_specific_dataset
from augmentation import balance_dataset
from train_deep_models import run_deep_cv
from train_hybrid import run_hybrid_cv
from statistical_analysis import compare_models
from visualization import (
    plot_class_distribution, plot_metric_comparison,
    plot_confusion_matrix_from_predictions, plot_roc_curves
)
from utils import ensure_dir, seed_everything


def preprocessing_values(setting):
    if setting == "both":
        return [True, False]
    return [setting == "on"]


def main():
    parser = argparse.ArgumentParser(
        description="Run the attention-enhanced dental X-ray paper experiments."
    )
    parser.add_argument(
        "--experiment", choices=["data", "custom", "pretrained", "hybrid", "all"],
        default="all"
    )
    parser.add_argument("--manifest", default=str(CONFIG.balanced_manifest))
    parser.add_argument("--preprocessing", choices=["on", "off", "both"], default="both")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--output-dir", default=str(CONFIG.output_root))

    parser.add_argument("--build-data", action="store_true")
    parser.add_argument("--image-dir")
    parser.add_argument("--annotation-dir")
    parser.add_argument("--annotation-format", choices=["yolo", "coco"], default="yolo")
    parser.add_argument("--coco-json")
    parser.add_argument("--data-yaml")
    parser.add_argument("--segmented-dir", default=str(CONFIG.segmented_dir))
    parser.add_argument("--balanced-dir", default=str(CONFIG.balanced_dir))
    args = parser.parse_args()

    seed_everything(CONFIG.random_seed)
    output_root = ensure_dir(args.output_dir)
    manifest_path = Path(args.manifest)

    if args.build_data or args.experiment == "data":
        if not args.image_dir:
            parser.error("--image-dir is required to build the dataset.")
        segmented_manifest = Path(args.segmented_dir) / "manifest.csv"
        build_class_specific_dataset(
            args.image_dir, args.annotation_dir, args.segmented_dir,
            args.annotation_format, args.coco_json, args.data_yaml
        )
        balance_dataset(
            segmented_manifest, args.balanced_dir,
            CONFIG.target_samples_per_class, CONFIG.random_seed
        )
        manifest_path = Path(args.balanced_dir) / "manifest.csv"
        plot_class_distribution(manifest_path, output_root / "dataset_distribution.png")
        if args.experiment == "data":
            return

    if not manifest_path.exists():
        parser.error(f"Manifest not found: {manifest_path}. Build it first or pass --manifest.")

    prep_options = preprocessing_values(args.preprocessing)
    result_frames = []

    if args.experiment in {"custom", "all"}:
        for prep in prep_options:
            for attention in (True, False):
                tag = f"custom_attention_{int(attention)}_prep_{int(prep)}"
                result_frames.append(run_deep_cv(
                    manifest_path, "custom_cnn", prep, attention,
                    output_root / tag, args.device
                ))

    if args.experiment in {"pretrained", "all"}:
        for model in ("vgg16", "resnet50", "xception"):
            for prep in prep_options:
                tag = f"{model}_attention_prep_{int(prep)}"
                result_frames.append(run_deep_cv(
                    manifest_path, model, prep, True, output_root / tag, args.device
                ))

    if args.experiment in {"hybrid", "all"}:
        for prep in prep_options:
            for attention in (True, False):
                tag = f"hybrid_attention_{int(attention)}_prep_{int(prep)}"
                result_frames.append(run_hybrid_cv(
                    manifest_path, prep, attention, output_root / tag, args.device
                ))

    if result_frames:
        combined = pd.concat(result_frames, ignore_index=True)
        combined_path = output_root / "all_experiment_fold_results.csv"
        combined.to_csv(combined_path, index=False)
        try:
            compare_models(
                combined_path, "accuracy",
                output_root / "statistical_comparisons.csv"
            )
        except Exception as exc:
            print(f"[WARN] Statistical comparison skipped: {exc}")

        for folder in output_root.iterdir():
            if not folder.is_dir():
                continue
            pred = folder / "predictions.csv"
            results = folder / "fold_results.csv"
            if pred.exists() and results.exists():
                try:
                    plot_metric_comparison(results, folder / "accuracy.png", "accuracy")
                    plot_confusion_matrix_from_predictions(pred, folder / "confusion_matrix.png")
                    plot_roc_curves(pred, folder / "roc_curves.png")
                except Exception as exc:
                    print(f"[WARN] Plot generation failed for {folder.name}: {exc}")


if __name__ == "__main__":
    main()
