import argparse

import cv2
import joblib
import numpy as np
import torch

from config import CONFIG
from preprocessing import apply_preprocessing
from train_deep_models import build_model
from utils import get_device


def predict_image(
    image_path, model_name, checkpoint_path, preprocess=True,
    use_attention=True, device=None, hybrid_classifier_path=None
):
    device = get_device() if device is None else device
    model = build_model(model_name, use_attention=use_attention)
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint.get("model_state_dict", checkpoint))
    model.to(device).eval()

    image = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise IOError(f"Cannot read input image: {image_path}")
    array = apply_preprocessing(image, enabled=preprocess)
    tensor = torch.from_numpy(
        np.ascontiguousarray(array.transpose(2, 0, 1))
    ).float().unsqueeze(0).to(device)

    with torch.no_grad():
        if hybrid_classifier_path:
            classifier = joblib.load(hybrid_classifier_path)
            features = model.extract_features(tensor).cpu().numpy()
            probabilities = classifier.predict_proba(features)[0]
        else:
            probabilities = torch.softmax(model(tensor), dim=1).cpu().numpy()[0]

    predicted = int(np.argmax(probabilities))
    return {
        "predicted_class": CONFIG.class_names[predicted],
        "class_probabilities": {
            name: float(probabilities[i]) for i, name in enumerate(CONFIG.class_names)
        }
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    parser.add_argument("--model", required=True,
                        choices=["custom_cnn", "vgg16", "resnet50", "xception"])
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--without-preprocessing", action="store_true")
    parser.add_argument("--without-attention", action="store_true")
    parser.add_argument("--hybrid-classifier")
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    print(predict_image(
        args.image, args.model, args.checkpoint,
        preprocess=not args.without_preprocessing,
        use_attention=not args.without_attention,
        device=get_device(args.device),
        hybrid_classifier_path=args.hybrid_classifier
    ))


if __name__ == "__main__":
    main()
