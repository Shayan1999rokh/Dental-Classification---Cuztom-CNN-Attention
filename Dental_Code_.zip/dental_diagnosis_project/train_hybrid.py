import pandas as pd
import joblib

from config import CONFIG
from dataset import DentalXrayDataset, make_dataloader
from cross_validation import make_grouped_folds
from custom_cnn import CustomDentalCNN
from feature_extraction import extract_feature_matrix, save_feature_bundle
from hybrid_classifiers import build_hybrid_classifier
from train_deep_models import train_one_fold
from evaluation import compute_classification_metrics
from utils import ensure_dir, get_device, load_manifest, seed_everything, save_json


def run_hybrid_cv(
    manifest_path, preprocess=True, use_attention=True, output_dir=None,
    device=None, classifiers=("svm", "rf", "dt")
):
    """
    For each fold:
      1. Train custom CNN on that fold's training partition.
      2. Extract features from train and validation partitions.
      3. Fit SVM/RF/DT on training features only.
      4. Evaluate on the held-out fold.
    """
    seed_everything(CONFIG.random_seed)
    device = get_device() if device is None else device
    manifest = load_manifest(manifest_path)
    output_dir = ensure_dir(
        output_dir or (
            CONFIG.output_root /
            f"hybrid_attn_{int(use_attention)}_prep_{int(preprocess)}"
        )
    )
    folds = make_grouped_folds(manifest)
    result_rows, prediction_frames = [], []

    for fold_id, (train_frame, val_frame) in enumerate(folds, start=1):
        print(f"\n--- Hybrid fold {fold_id}/{len(folds)} ---")
        train_ds = DentalXrayDataset(
            train_frame, preprocess=preprocess, return_metadata=True
        )
        val_ds = DentalXrayDataset(
            val_frame, preprocess=preprocess, return_metadata=True
        )
        train_loader = make_dataloader(
            train_ds, CONFIG.custom_batch_size, shuffle=True
        )
        train_feature_loader = make_dataloader(
            train_ds, CONFIG.custom_batch_size, shuffle=False
        )
        val_loader = make_dataloader(
            val_ds, CONFIG.custom_batch_size, shuffle=False
        )

        cnn = CustomDentalCNN(num_classes=4, use_attention=use_attention)
        fold_dir = ensure_dir(output_dir / f"fold_{fold_id}")
        cnn, _, _ = train_one_fold(
            cnn, train_loader, val_loader, "custom_cnn",
            fold_dir / "cnn", device
        )
        x_train, y_train, train_groups = extract_feature_matrix(
            cnn, train_feature_loader, device
        )
        x_val, y_val, val_groups = extract_feature_matrix(cnn, val_loader, device)
        save_feature_bundle(
            x_train, y_train, fold_dir / "train_features.npz", train_groups
        )
        save_feature_bundle(
            x_val, y_val, fold_dir / "validation_features.npz", val_groups
        )

        for classifier_name in classifiers:
            classifier = build_hybrid_classifier(classifier_name)
            classifier.fit(x_train, y_train)
            y_pred = classifier.predict(x_val)
            y_prob = classifier.predict_proba(x_val)
            metrics = compute_classification_metrics(
                y_val, y_pred, y_prob, num_classes=4
            )
            model_label = f"cnn_{classifier_name}"
            result_rows.append({
                "fold": fold_id,
                "model": model_label,
                "attention": bool(use_attention),
                "preprocessing": bool(preprocess),
                **{k: v for k, v in metrics.items()
                   if k not in {"confusion_matrix", "classification_report"}},
            })
            pred_frame = val_frame.reset_index(drop=True).copy()
            pred_frame["model"] = model_label
            pred_frame["y_true"] = y_val
            pred_frame["y_pred"] = y_pred
            for class_id in range(4):
                pred_frame[f"prob_{class_id}"] = y_prob[:, class_id]
            prediction_frames.append(pred_frame)

            joblib.dump(classifier, fold_dir / f"{classifier_name}_classifier.joblib")
            save_json(metrics, fold_dir / f"{classifier_name}_metrics.json")

    results = pd.DataFrame(result_rows)
    results.to_csv(output_dir / "fold_results.csv", index=False)
    pd.concat(prediction_frames, ignore_index=True).to_csv(
        output_dir / "predictions.csv", index=False
    )
    metrics = [
        "accuracy", "precision_macro", "recall_macro", "f1_macro",
        "roc_auc_macro_ovr", "hamming_loss"
    ]
    save_json(results[metrics].agg(["mean", "std"]).to_dict(),
              output_dir / "summary.json")
    return results
