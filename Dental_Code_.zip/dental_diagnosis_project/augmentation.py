import argparse
import shutil
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

from config import CONFIG
from utils import load_manifest, seed_everything

def augment_image(image, rng, max_rotation=15.0):
    h, w = image.shape[:2]
    angle = float(rng.uniform(-max_rotation, max_rotation))
    matrix = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    result = cv2.warpAffine(
        image, matrix, (w, h), flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT, borderValue=0
    )
    ops = [f"rotation:{angle:.3f}"]
    if rng.random() < 0.5:
        result = cv2.flip(result, 1)
        ops.append("horizontal_flip")
    if rng.random() < 0.5:
        result = cv2.flip(result, 0)
        ops.append("vertical_flip")
    return result, "+".join(ops)

def balance_dataset(
    input_manifest, output_dir=None, target_per_class=None,
    seed=42, max_rotation=15.0
):
    """
    Offline balancing to the paper's 1,191/class. Augmented samples retain the
    parent original_image_id so GroupKFold can keep related samples together.
    """
    frame = load_manifest(input_manifest)
    output_dir = Path(output_dir or CONFIG.balanced_dir)
    target = int(target_per_class or CONFIG.target_samples_per_class)
    rng = np.random.default_rng(seed)
    output_rows = []

    for label in CONFIG.class_names:
        source_rows = frame[frame.label == label].to_dict("records")
        n = len(source_rows)
        if n > target:
            raise ValueError(f"{label}: {n} exceeds target {target}; no downsampling is performed.")
        if n == 0:
            raise ValueError(f"{label} has no samples.")
        class_dir = output_dir / label.lower().replace(" ", "_")
        class_dir.mkdir(parents=True, exist_ok=True)

        for row in source_rows:
            src = Path(row["image_path"])
            dst = class_dir / f"{row['sample_id']}{src.suffix.lower()}"
            shutil.copy2(src, dst)
            copy_row = dict(row)
            copy_row.update(image_path=str(dst.resolve()), is_augmented=False, augmentation="none")
            output_rows.append(copy_row)

        for aug_i in range(target - n):
            parent = source_rows[int(rng.integers(0, n))]
            src = Path(parent["image_path"])
            image = cv2.imread(str(src), cv2.IMREAD_GRAYSCALE)
            if image is None:
                raise IOError(f"Cannot read {src}")
            augmented, operations = augment_image(image, rng, max_rotation)
            sample_id = f"{parent['sample_id']}_aug_{aug_i:05d}"
            dst = class_dir / f"{sample_id}.png"
            if not cv2.imwrite(str(dst), augmented):
                raise IOError(f"Cannot write {dst}")
            row = dict(parent)
            row.update(
                sample_id=sample_id, image_path=str(dst.resolve()),
                is_augmented=True, augmentation=operations
            )
            output_rows.append(row)

    balanced = pd.DataFrame(output_rows)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / "manifest.csv"
    balanced.to_csv(manifest_path, index=False)
    print(balanced.label.value_counts().reindex(CONFIG.class_names, fill_value=0))
    print(f"Balanced samples: {len(balanced)}; manifest: {manifest_path}")
    return balanced

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", default=str(CONFIG.segmented_manifest))
    parser.add_argument("--output-dir", default=str(CONFIG.balanced_dir))
    parser.add_argument("--target-per-class", type=int, default=CONFIG.target_samples_per_class)
    parser.add_argument("--seed", type=int, default=CONFIG.random_seed)
    args = parser.parse_args()
    seed_everything(args.seed)
    balance_dataset(args.manifest, args.output_dir, args.target_per_class, args.seed)

if __name__ == "__main__":
    main()
