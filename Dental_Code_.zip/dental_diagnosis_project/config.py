from dataclasses import dataclass, field
from pathlib import Path
from typing import Tuple

@dataclass
class ProjectConfig:
    project_root: Path = field(default_factory=lambda: Path(__file__).resolve().parent)
    data_root: Path = field(default_factory=lambda: Path(__file__).resolve().parent / "data")
    output_root: Path = field(default_factory=lambda: Path(__file__).resolve().parent / "outputs")
    class_names: Tuple[str, ...] = ("Fillings", "Cavity", "Implant", "Impacted Tooth")
    image_size: int = 128
    n_splits: int = 5
    random_seed: int = 42
    num_workers: int = 0
    custom_batch_size: int = 16       # Table 3; prose also reports 32
    custom_epochs: int = 30           # Table 3; prose also reports 50
    custom_learning_rate: float = 1e-3
    pretrained_batch_size: int = 8
    pretrained_epochs: int = 30
    pretrained_learning_rate: float = 1e-4
    early_stopping_patience: int = 10
    scheduler_patience: int = 5
    scheduler_factor: float = 0.5
    minimum_learning_rate: float = 1e-7
    brightness_alpha: float = 1.5
    brightness_beta: int = 15
    clahe_clip_limit: float = 2.0
    clahe_tile_grid_size: Tuple[int, int] = (3, 3)
    augmentation_rotation_degrees: float = 15.0
    target_samples_per_class: int = 1191
    random_forest_estimators: int = 100
    svm_c: float = 1.0
    svm_gamma: str = "scale"
    svm_kernel: str = "rbf"

    @property
    def class_to_idx(self):
        return {name: i for i, name in enumerate(self.class_names)}

    @property
    def segmented_dir(self):
        return self.data_root / "segmented"

    @property
    def balanced_dir(self):
        return self.data_root / "balanced"

    @property
    def segmented_manifest(self):
        return self.segmented_dir / "manifest.csv"

    @property
    def balanced_manifest(self):
        return self.balanced_dir / "manifest.csv"

    def ensure_directories(self):
        for path in (self.data_root, self.output_root, self.segmented_dir, self.balanced_dir):
            path.mkdir(parents=True, exist_ok=True)

CONFIG = ProjectConfig()
