from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau

from config import CONFIG
from custom_cnn import CustomDentalCNN
from pretrained_models import build_pretrained_model
from dataset import DentalXrayDataset, make_dataloader
from cross_validation import make_grouped_folds
from evaluation import compute_classification_metrics
from utils import ensure_dir, get_device, load_manifest, save_json, seed_everything


def build_model(model_name, use_attention=True, num_classes=4):
    if model_name == "custom_cnn":
        return CustomDentalCNN(num_classes=num_classes, use_attention=use_attention)
    if model_name in {"vgg16", "resnet50", "xception"}:
        return build_pretrained_model(model_name, num_classes=num_classes, pretrained=True)
    raise ValueError(f"Unknown model name: {model_name}")


def _run_epoch(model, loader, criterion, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total_loss = 0.0
    labels_all, predictions_all, probabilities_all = [], [], []

    for batch in loader:
        images, labels = batch[0].to(device), batch[1].to(device)
        if training:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(training):
            logits = model(images)
            loss = criterion(logits, labels)
            if training:
                loss.backward()
                optimizer.step()

        probabilities = torch.softmax(logits.detach(), dim=1)
        predictions = probabilities.argmax(dim=1)
        total_loss += float(loss.item()) * len(labels)
        labels_all.extend(labels.detach().cpu().numpy())
        predictions_all.extend(predictions.cpu().numpy())
        probabilities_all.extend(probabilities.cpu().numpy())

    return (
        total_loss / max(1, len(loader.dataset)),
        np.asarray(labels_all),
        np.asarray(predictions_all),
        np.asarray(probabilities_all),
    )


def train_one_fold(model, train_loader, val_loader, model_name, fold_dir, device=None):
    device = get_device() if device is None else device
    fold_dir = ensure_dir(fold_dir)
    model = model.to(device)

    if model_name == "custom_cnn":
        lr, max_epochs = CONFIG.custom_learning_rate, CONFIG.custom_epochs
    else:
        lr, max_epochs = CONFIG.pretrained_learning_rate, CONFIG.pretrained_epochs

    parameters = [p for p in model.parameters() if p.requires_grad]
    optimizer = Adam(parameters, lr=lr)
    criterion = nn.CrossEntropyLoss()
    scheduler = ReduceLROnPlateau(
        optimizer, mode="max", factor=CONFIG.scheduler_factor,
        patience=CONFIG.scheduler_patience, min_lr=CONFIG.minimum_learning_rate
    )

    best_accuracy = -1.0
    best_epoch = 0
    stale_epochs = 0
    history = []

    for epoch in range(1, max_epochs + 1):
        train_loss, _, _, _ = _run_epoch(
            model, train_loader, criterion, device, optimizer
        )
        val_loss, y_true, y_pred, _ = _run_epoch(
            model, val_loader, criterion, device
        )
        val_accuracy = float(np.mean(y_true == y_pred))
        scheduler.step(val_accuracy)
        history.append({
            "epoch": epoch,
            "train_loss": train_loss,
            "val_loss": val_loss,
            "val_accuracy": val_accuracy,
            "learning_rate": optimizer.param_groups[0]["lr"],
        })

        if val_accuracy > best_accuracy:
            best_accuracy = val_accuracy
            best_epoch = epoch
            stale_epochs = 0
            torch.save(
                {"model_state_dict": model.state_dict(), "epoch": epoch},
                fold_dir / "best_model.pt",
            )
        else:
            stale_epochs += 1

        print(
            f"[{model_name}] epoch {epoch}/{max_epochs} "
            f"train_loss={train_loss:.4f} val_loss={val_loss:.4f} "
            f"val_accuracy={val_accuracy:.4f}"
        )
        if stale_epochs >= CONFIG.early_stopping_patience:
            break

    checkpoint = torch.load(
        fold_dir / "best_model.pt", map_location=device, weights_only=False
    )
    model.load_state_dict(checkpoint["model_state_dict"])
    val_loss, y_true, y_pred, y_prob = _run_epoch(
        model, val_loader, criterion, device
    )
    metrics = compute_classification_metrics(y_true, y_pred, y_prob, num_classes=4)
    metrics["val_loss"] = float(val_loss)
    metrics["best_epoch"] = int(best_epoch)
    save_json(history, fold_dir / "training_history.json")
    return model, metrics, {"y_true": y_true, "y_pred": y_pred, "y_prob": y_prob}


def run_deep_cv(
    manifest_path, model_name, preprocess=True, use_attention=True,
    output_dir=None, device=None
):
    seed_everything(CONFIG.random_seed)
    device = get_device() if device is None else device
    manifest = load_manifest(manifest_path)
    output_dir = ensure_dir(
        output_dir or (
            CONFIG.output_root /
            f"{model_name}_attention_{int(use_attention)}_prep_{int(preprocess)}"
        )
    )
    folds = make_grouped_folds(manifest)
    rows, prediction_frames = [], []

    batch_size = (
        CONFIG.custom_batch_size if model_name == "custom_cnn"
        else CONFIG.pretrained_batch_size
    )

    for fold_id, (train_frame, val_frame) in enumerate(folds, start=1):
        print(f"\n--- {model_name}: fold {fold_id}/{len(folds)} ---")
        train_ds = DentalXrayDataset(train_frame, preprocess=preprocess)
        val_ds = DentalXrayDataset(
            val_frame, preprocess=preprocess, return_metadata=True
        )
        train_loader = make_dataloader(train_ds, batch_size, shuffle=True)
        val_loader = make_dataloader(val_ds, batch_size, shuffle=False)

        model = build_model(model_name, use_attention=use_attention)
        fold_dir = ensure_dir(output_dir / f"fold_{fold_id}")
        model, metrics, outputs = train_one_fold(
            model, train_loader, val_loader, model_name, fold_dir, device
        )

        rows.append({
            "fold": fold_id,
            "model": model_name,
            "attention": bool(use_attention),
            "preprocessing": bool(preprocess),
            **{k: v for k, v in metrics.items()
               if k not in {"confusion_matrix", "classification_report"}},
        })
        pred_frame = val_frame.reset_index(drop=True).copy()
        pred_frame["y_true"] = outputs["y_true"]
        pred_frame["y_pred"] = outputs["y_pred"]
        for class_id in range(4):
            pred_frame[f"prob_{class_id}"] = outputs["y_prob"][:, class_id]
        prediction_frames.append(pred_frame)
        save_json(metrics, fold_dir / "metrics.json")

    results = pd.DataFrame(rows)
    results.to_csv(output_dir / "fold_results.csv", index=False)
    pd.concat(prediction_frames, ignore_index=True).to_csv(
        output_dir / "predictions.csv", index=False
    )
    metric_cols = [
        "accuracy", "precision_macro", "recall_macro", "f1_macro",
        "roc_auc_macro_ovr", "hamming_loss"
    ]
    save_json(results[metric_cols].agg(["mean", "std"]).to_dict(),
              output_dir / "summary.json")
    return results
