import torch
from torch import nn

class SpatialAttentionBlock(nn.Module):
    """
    Spatial attention consistent with the paper's equations:
      e = tanh(W^T X + b), a = softmax(e), X_att = X * a.
    For tensor shape [B,C,H,W], scores are computed over H*W positions.
    """
    def __init__(self, channels):
        super().__init__()
        self.score_projection = nn.Conv1d(channels, 1, kernel_size=1, bias=True)

    def forward(self, feature_map, return_attention=False):
        batch, channels, height, width = feature_map.shape
        sequence = feature_map.reshape(batch, channels, height * width)
        scores = torch.tanh(self.score_projection(sequence))
        weights = torch.softmax(scores, dim=-1)
        attended = (sequence * weights).reshape(batch, channels, height, width)
        if return_attention:
            return attended, weights.reshape(batch, 1, height, width)
        return attended
