from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, roc_curve, auc
from sklearn.preprocessing import label_binarize

from config import CONFIG


def plot_class_distribution(manifest_csv, output_path):
    frame = pd.read_csv(manifest_csv)
    counts = frame["label"].value_counts().reindex(CONFIG.class_names, fill_value=0)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(counts.index, counts.values)
    ax.set_ylabel("Number of samples")
    ax.set_title("Dental X-ray class distribution")
    ax.tick_params(axis="x", rotation=20)
    fig.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=300)
    plt.close(fig)


def plot_metric_comparison(results_csv, output_path, metric="accuracy"):
    frame = pd.read_csv(results_csv)
    summary = frame.groupby("model")[metric].agg(["mean", "std"]).sort_values("mean")
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(summary.index, summary["mean"], yerr=summary["std"].fillna(0), capsize=4)
    ax.set_ylabel(metric.replace("_", " ").title())
    ax.set_ylim(0, 1.05)
    ax.set_title(f"Model comparison: {metric}")
    ax.tick_params(axis="x", rotation=30)
    fig.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=300)
    plt.close(fig)


def plot_confusion_matrix_from_predictions(
    predictions_csv, output_path, model_name=None, normalize=False
):
    frame = pd.read_csv(predictions_csv)
    if model_name and "model" in frame.columns:
        frame = frame[frame["model"] == model_name]
    matrix = confusion_matrix(
        frame["y_true"], frame["y_pred"], labels=list(range(len(CONFIG.class_names)))
    )
    shown = matrix.astype(float)
    if normalize:
        sums = shown.sum(axis=1, keepdims=True)
        shown = np.divide(shown, sums, out=np.zeros_like(shown), where=sums != 0)

    fig, ax = plt.subplots(figsize=(7, 6))
    image = ax.imshow(shown, interpolation="nearest")
    fig.colorbar(image, ax=ax)
    ax.set(
        xticks=np.arange(4), yticks=np.arange(4),
        xticklabels=CONFIG.class_names, yticklabels=CONFIG.class_names,
        xlabel="Predicted label", ylabel="True label", title="Confusion matrix"
    )
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    threshold = shown.max() / 2 if shown.size else 0
    for i in range(4):
        for j in range(4):
            value = f"{shown[i, j]:.2f}" if normalize else str(int(shown[i, j]))
            ax.text(j, i, value, ha="center", va="center",
                    color="white" if shown[i, j] > threshold else "black")
    fig.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=300)
    plt.close(fig)


def plot_roc_curves(predictions_csv, output_path, model_name=None):
    frame = pd.read_csv(predictions_csv)
    if model_name and "model" in frame.columns:
        frame = frame[frame["model"] == model_name]
    y_true = frame["y_true"].to_numpy(dtype=int)
    prob_cols = [f"prob_{i}" for i in range(4)]
    y_prob = frame[prob_cols].to_numpy(dtype=float)
    y_binary = label_binarize(y_true, classes=list(range(4)))

    fig, ax = plt.subplots(figsize=(8, 6))
    for class_id, class_name in enumerate(CONFIG.class_names):
        if len(np.unique(y_binary[:, class_id])) < 2:
            continue
        fpr, tpr, _ = roc_curve(y_binary[:, class_id], y_prob[:, class_id])
        ax.plot(fpr, tpr, label=f"{class_name} (AUC={auc(fpr, tpr):.3f})")
    ax.plot([0, 1], [0, 1], linestyle="--")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("One-vs-rest ROC curves")
    ax.legend()
    fig.tight_layout()
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=300)
    plt.close(fig)
