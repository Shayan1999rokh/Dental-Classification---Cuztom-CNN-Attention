import numpy as np
import torch


@torch.no_grad()
def extract_feature_matrix(model, dataloader, device=None):
    """
    Extract flattened attention-enhanced CNN features. For the custom CNN
    at 128x128 input this is 256*16*16 = 65,536 features per sample.
    """
    device = device or next(model.parameters()).device
    model.eval()
    feature_batches, label_batches, group_ids = [], [], []
    for batch in dataloader:
        images, labels = batch[0].to(device), batch[1]
        features = model.extract_features(images)
        feature_batches.append(features.cpu().numpy().astype(np.float32))
        label_batches.append(labels.numpy().astype(np.int64))
        if len(batch) > 2:
            group_ids.extend(list(batch[2]))
    return (
        np.concatenate(feature_batches, axis=0),
        np.concatenate(label_batches, axis=0),
        group_ids,
    )


def save_feature_bundle(features, labels, path, group_ids=None):
    payload = {"features": features, "labels": labels}
    if group_ids is not None:
        payload["group_ids"] = np.asarray(group_ids, dtype=str)
    np.savez_compressed(path, **payload)
