import torch
from torch import nn

from attention import SpatialAttentionBlock

class CustomDentalCNN(nn.Module):
    """
    Custom CNN based on Table 3:
    Conv64-Pool-Dropout, Conv128-Pool-Dropout, Conv256-Pool-Dropout,
    optional Attention, Flatten, Dense256, Dense128, Softmax logits.
    """
    def __init__(self, num_classes=4, use_attention=True, input_channels=3):
        super().__init__()
        self.use_attention = bool(use_attention)
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_channels, 64, 3, padding=1),
            nn.ReLU(inplace=True), nn.MaxPool2d(2), nn.Dropout2d(0.4)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(64, 128, 3, padding=1),
            nn.ReLU(inplace=True), nn.MaxPool2d(2), nn.Dropout2d(0.5)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(128, 256, 3, padding=1),
            nn.ReLU(inplace=True), nn.MaxPool2d(2), nn.Dropout2d(0.4)
        )
        self.attention = SpatialAttentionBlock(256) if use_attention else nn.Identity()
        # 128x128 -> 16x16 after three 2x2 pooling operations.
        self.feature_dim = 256 * 16 * 16
        self.classifier = nn.Sequential(
            nn.Linear(self.feature_dim, 256), nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, 128), nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(128, num_classes)
        )

    def extract_feature_map(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        return self.attention(x)

    def extract_features(self, x):
        return torch.flatten(self.extract_feature_map(x), start_dim=1)

    def forward(self, x):
        return self.classifier(self.extract_features(x))
