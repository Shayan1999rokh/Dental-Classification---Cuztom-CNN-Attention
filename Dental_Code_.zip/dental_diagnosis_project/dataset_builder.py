import argparse
import json
import re
from pathlib import Path

import cv2
import pandas as pd
import yaml

from config import CONFIG

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}

def canonical_class_name(raw_name):
    text = re.sub(r"\s+", " ", str(raw_name).strip().lower().replace("_", " ").replace("-", " "))
    aliases = {
        "filling": "Fillings", "fillings": "Fillings",
        "cavity": "Cavity", "cavities": "Cavity", "caries": "Cavity",
        "dental caries": "Cavity",
        "implant": "Implant", "implants": "Implant",
        "impacted tooth": "Impacted Tooth", "impacted teeth": "Impacted Tooth",
    }
    candidate = aliases.get(text)
    if candidate in CONFIG.class_names:
        return candidate
    for name in CONFIG.class_names:
        if name.lower() == text:
            return name
    return None

def read_yolo_names(data_yaml=None):
    if not data_yaml:
        return list(CONFIG.class_names)
    payload = yaml.safe_load(Path(data_yaml).read_text(encoding="utf-8")) or {}
    names = payload.get("names", list(CONFIG.class_names))
    if isinstance(names, dict):
        names = [names[k] for k in sorted(names, key=lambda x: int(x))]
    return list(names)

def parse_yolo_labels(label_path, width, height, names):
    boxes = []
    label_path = Path(label_path)
    if not label_path.exists():
        return boxes
    for line in label_path.read_text(encoding="utf-8").splitlines():
        parts = line.split()
        if len(parts) < 5:
            continue
        try:
            class_id = int(float(parts[0]))
            xc, yc, bw, bh = map(float, parts[1:5])
        except ValueError:
            continue
        if not 0 <= class_id < len(names):
            continue
        label = canonical_class_name(names[class_id])
        if label is None:
            continue
        boxes.append((
            label,
            int(round((xc - bw / 2) * width)),
            int(round((yc - bh / 2) * height)),
            int(round((xc + bw / 2) * width)),
            int(round((yc + bh / 2) * height)),
        ))
    return boxes

def load_coco_index(coco_json):
    payload = json.loads(Path(coco_json).read_text(encoding="utf-8"))
    category_map = {
        c["id"]: canonical_class_name(c["name"])
        for c in payload.get("categories", [])
    }
    image_map = {i["id"]: i for i in payload.get("images", [])}
    result = {}
    for ann in payload.get("annotations", []):
        info = image_map.get(ann.get("image_id"))
        label = category_map.get(ann.get("category_id"))
        if not info or label is None:
            continue
        x, y, w, h = ann["bbox"]
        box = (label, x, y, x + w, y + h)
        name = str(info["file_name"]).replace("\\", "/")
        result.setdefault(name, []).append(box)
        basename = Path(name).name
        if basename != name:
            result.setdefault(basename, []).append(box)
    return result

def locate_yolo_label(image_path, image_root, annotation_dir):
    rel = Path(image_path).relative_to(image_root)
    candidates = [
        Path(annotation_dir) / rel.with_suffix(".txt"),
        Path(annotation_dir) / f"{Path(image_path).stem}.txt",
        Path(annotation_dir) / Path(image_path).parent.name / f"{Path(image_path).stem}.txt",
    ]
    return next((p for p in candidates if p.exists()), candidates[0])

def build_class_specific_dataset(
    image_dir, annotation_dir=None, output_dir=None,
    annotation_format="yolo", coco_json=None, data_yaml=None
):
    """
    Make one class-specific masked image for every class present in an original
    radiograph. The mask is the union of that class's annotated rectangles.
    This reproduces the paper's bounding-box masking, not learned segmentation.
    """
    image_dir = Path(image_dir)
    output_dir = Path(output_dir or CONFIG.segmented_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if annotation_format == "yolo":
        if annotation_dir is None:
            raise ValueError("YOLO mode requires --annotation-dir.")
        names = read_yolo_names(data_yaml)
        coco_index = None
    elif annotation_format == "coco":
        if coco_json is None:
            raise ValueError("COCO mode requires --coco-json.")
        coco_index = load_coco_index(coco_json)
        names = None
    else:
        raise ValueError("annotation_format must be yolo or coco.")

    images = sorted(p for p in image_dir.rglob("*")
                    if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
    if not images:
        raise FileNotFoundError(f"No images found under {image_dir}")

    rows = []
    for image_number, image_path in enumerate(images):
        image = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
        if image is None:
            print(f"[WARN] unreadable image: {image_path}")
            continue
        h, w = image.shape
        original_id = image_path.relative_to(image_dir).as_posix()

        if annotation_format == "yolo":
            label_path = locate_yolo_label(image_path, image_dir, annotation_dir)
            boxes = parse_yolo_labels(label_path, w, h, names)
        else:
            boxes = coco_index.get(original_id, coco_index.get(image_path.name, []))

        by_class = {}
        for box in boxes:
            by_class.setdefault(box[0], []).append(box)

        for label, class_boxes in by_class.items():
            mask = image * 0
            valid = 0
            for _, x1, y1, x2, y2 in class_boxes:
                x1, x2 = max(0, min(w - 1, int(x1))), max(0, min(w, int(x2)))
                y1, y2 = max(0, min(h - 1, int(y1))), max(0, min(h, int(y2)))
                if x2 <= x1 or y2 <= y1:
                    continue
                cv2.rectangle(mask, (x1, y1), (x2, y2), 255, -1)
                valid += 1
            if not valid:
                continue
            masked = cv2.bitwise_and(image, image, mask=mask)
            slug = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
            class_dir = output_dir / slug
            class_dir.mkdir(parents=True, exist_ok=True)
            sample_id = f"{image_number:06d}_{slug}"
            destination = class_dir / f"{sample_id}.png"
            if not cv2.imwrite(str(destination), masked):
                raise IOError(f"Could not save {destination}")
            rows.append({
                "sample_id": sample_id,
                "image_path": str(destination.resolve()),
                "label": label,
                "label_id": CONFIG.class_to_idx[label],
                "original_image_id": original_id,
                "original_path": str(image_path.resolve()),
                "bbox_count": valid,
                "is_augmented": False,
                "augmentation": "none",
            })

    frame = pd.DataFrame(rows)
    if frame.empty:
        raise RuntimeError("No samples created; verify annotation format, paths and class names.")
    manifest_path = output_dir / "manifest.csv"
    frame.to_csv(manifest_path, index=False)
    print(frame["label"].value_counts().reindex(CONFIG.class_names, fill_value=0))
    print(f"Created {len(frame)} class-specific samples: {manifest_path}")
    return frame

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-dir", required=True)
    parser.add_argument("--annotation-dir")
    parser.add_argument("--annotation-format", choices=["yolo", "coco"], default="yolo")
    parser.add_argument("--coco-json")
    parser.add_argument("--data-yaml")
    parser.add_argument("--output-dir", default=str(CONFIG.segmented_dir))
    args = parser.parse_args()
    build_class_specific_dataset(
        args.image_dir, args.annotation_dir, args.output_dir,
        args.annotation_format, args.coco_json, args.data_yaml
    )

if __name__ == "__main__":
    main()
