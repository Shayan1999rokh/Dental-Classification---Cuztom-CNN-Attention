import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    hamming_loss, roc_auc_score, confusion_matrix, classification_report
)

def compute_classification_metrics(y_true, y_pred, y_prob=None, num_classes=4):
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    labels = list(range(num_classes))
    result = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_macro": float(precision_score(
            y_true, y_pred, labels=labels, average="macro", zero_division=0
        )),
        "recall_macro": float(recall_score(
            y_true, y_pred, labels=labels, average="macro", zero_division=0
        )),
        "f1_macro": float(f1_score(
            y_true, y_pred, labels=labels, average="macro", zero_division=0
        )),
        "hamming_loss": float(hamming_loss(y_true, y_pred)),
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
        "classification_report": classification_report(
            y_true, y_pred, labels=labels, output_dict=True, zero_division=0
        ),
    }
    try:
        result["roc_auc_macro_ovr"] = float(roc_auc_score(
            y_true, np.asarray(y_prob), labels=labels,
            multi_class="ovr", average="macro"
        )) if y_prob is not None else float("nan")
    except ValueError:
        result["roc_auc_macro_ovr"] = float("nan")
    return result
